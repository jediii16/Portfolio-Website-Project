import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class SAandVolCalc {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Surface Area and Volume Calculator"); // to create the main application window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600);
        frame.setLocationRelativeTo(null);

        JPanel contentPane = new JPanel(new BorderLayout()); // contains everything
        contentPane.setBackground(new Color(30, 60, 90)); // dark blue for the background
        frame.setContentPane(contentPane);

        JPanel formPanel = new JPanel(new GridBagLayout()); // for making the panel
        formPanel.setBorder(new EmptyBorder(30, 40, 30, 40));
        formPanel.setBackground(new Color(30, 60, 90));

        GridBagConstraints gbc = new GridBagConstraints(); // for the layouts
        gbc.insets = new Insets(10, 10, 10, 10); // paddings
        gbc.fill = GridBagConstraints.HORIZONTAL; // expands the window horizontally
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel title = new JLabel("Surface Area and Volume Calculator"); // title
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        gbc.gridwidth = 2;
        formPanel.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++; // to move down

        formPanel.add(styledLabel("Shapes:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> shapeselected = new JComboBox<>(new String[]{"Select","Prism", "Pyramid", "Cylinder", "Cone", "Sphere"});
        formPanel.add(shapeselected, gbc);
        gbc.gridx = 0;
        gbc.gridy++; // to move down

        // to make panel for each shapes
        JPanel conePanel = new JPanel(new GridBagLayout());
        JPanel cylinderPanel = new JPanel(new GridBagLayout());
        JPanel spherePanel = new JPanel(new GridBagLayout());
        JPanel prismPanel = new JPanel(new GridBagLayout());
        JPanel pyramidPanel = new JPanel(new GridBagLayout());

       
        for (JPanel panel : new JPanel[]{conePanel, cylinderPanel, spherePanel, prismPanel, pyramidPanel}) {
            panel.setOpaque(false);
        }

        GridBagConstraints cgbc = new GridBagConstraints();
        cgbc.insets = new Insets(5, 5, 5, 5);
        cgbc.fill = GridBagConstraints.HORIZONTAL;

      
        cgbc.gridx = 0; cgbc.gridy = 0;
        conePanel.add(styledLabel("Radius:"), cgbc); // for cone radius
        cgbc.gridx = 1;
        JTextField coneRadius = new JTextField(15);
        conePanel.add(coneRadius, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        conePanel.add(styledLabel("Height:"), cgbc); // for cone height
        cgbc.gridx = 1;
        JTextField coneHeight = new JTextField(15);
        conePanel.add(coneHeight, cgbc);

        
        cgbc.gridx = 0; cgbc.gridy++;
        conePanel.add(styledLabel("Volume:"), cgbc); // volume of the cone
        cgbc.gridx = 1;
        JLabel coneVolume = styledLabel("");
        conePanel.add(coneVolume, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        conePanel.add(styledLabel("Surface area:"), cgbc); // surface area of the cone
        cgbc.gridx = 1;
        JLabel coneSurface = styledLabel("");
        conePanel.add(coneSurface, cgbc);

        
        cgbc.gridx = 0; cgbc.gridy = 0;
        cylinderPanel.add(styledLabel("Radius:"), cgbc); // for cylinder radius
        cgbc.gridx = 1;
        JTextField cylinderRadius = new JTextField(15);
        cylinderPanel.add(cylinderRadius, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        cylinderPanel.add(styledLabel("Height:"), cgbc); // for cylinder height
        cgbc.gridx = 1;
        JTextField cylinderHeight = new JTextField(15);
        cylinderPanel.add(cylinderHeight, cgbc);

        
        cgbc.gridx = 0; cgbc.gridy++;
        cylinderPanel.add(styledLabel("Volume:"), cgbc); // volume of the cylinder
        cgbc.gridx = 1;
        JLabel cylinderVolume = styledLabel("");
        cylinderPanel.add(cylinderVolume, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        cylinderPanel.add(styledLabel("Surface Area:"), cgbc); // surface area of the cylinder
        cgbc.gridx = 1;
        JLabel cylinderSurface = styledLabel("");
        cylinderPanel.add(cylinderSurface, cgbc);

     
        cgbc.gridx = 0; cgbc.gridy = 0;
        spherePanel.add(styledLabel("Radius:"), cgbc); // for the radius of the sphere
        cgbc.gridx = 1;
        JTextField sphereRadius = new JTextField(15);
        spherePanel.add(sphereRadius, cgbc);

      
        cgbc.gridx = 0; cgbc.gridy++;
        spherePanel.add(styledLabel("Volume:"), cgbc); // volume of the sphere
        cgbc.gridx = 1;
        JLabel sphereVolume = styledLabel("");
        spherePanel.add(sphereVolume, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        spherePanel.add(styledLabel("Surface Area:"), cgbc); // surface area of the sphere
        cgbc.gridx = 1;
        JLabel sphereSurface = styledLabel("");
        spherePanel.add(sphereSurface, cgbc);

       
        cgbc.gridx = 0; cgbc.gridy = 0;
        prismPanel.add(styledLabel("Width:"), cgbc);
        cgbc.gridx = 1;
        JTextField prismWidth = new JTextField(15); // width of the prism
        prismPanel.add(prismWidth, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        prismPanel.add(styledLabel("Length:"), cgbc); // length of the prism
        cgbc.gridx = 1;
        JTextField prismLength = new JTextField(15);
        prismPanel.add(prismLength, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        prismPanel.add(styledLabel("Height:"), cgbc); // height of the prism
        cgbc.gridx = 1;
        JTextField prismHeight = new JTextField(15);
        prismPanel.add(prismHeight, cgbc);

    
        cgbc.gridx = 0; cgbc.gridy++;
        prismPanel.add(styledLabel("Volume:"), cgbc); // volume of the prism
        cgbc.gridx = 1;
        JLabel prismVolume = styledLabel("");
        prismPanel.add(prismVolume, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        prismPanel.add(styledLabel("Surface Area:"), cgbc); // surface area of the prism
        cgbc.gridx = 1;
        JLabel prismSurface = styledLabel("");
        prismPanel.add(prismSurface, cgbc);

     
        cgbc.gridx = 0; cgbc.gridy = 0;
        pyramidPanel.add(styledLabel("Width:"), cgbc); //width of the pyramid
        cgbc.gridx = 1;
        JTextField pyramidWidth = new JTextField(15);
        pyramidPanel.add(pyramidWidth, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        pyramidPanel.add(styledLabel("Length:"), cgbc); //length of the pyramid
        cgbc.gridx = 1;
        JTextField pyramidLength = new JTextField(15);
        pyramidPanel.add(pyramidLength, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        pyramidPanel.add(styledLabel("Height:"), cgbc); // height of the pyramid
        cgbc.gridx = 1;
        JTextField pyramidHeight = new JTextField(15);
        pyramidPanel.add(pyramidHeight, cgbc);
       
        cgbc.gridx = 0; cgbc.gridy++;
        pyramidPanel.add(styledLabel("Volume:"), cgbc); // volume of the pyramid
        cgbc.gridx = 1;
        JLabel pyramidVolume = styledLabel("");
        pyramidPanel.add(pyramidVolume, cgbc);

        cgbc.gridx = 0; cgbc.gridy++;
        pyramidPanel.add(styledLabel("Surface Area:"), cgbc); // surface area of the pyramid
        cgbc.gridx = 1;
        JLabel pyramidSurface = styledLabel("");
        pyramidPanel.add(pyramidSurface, cgbc);

        gbc.gridwidth = 2;
        formPanel.add(conePanel, gbc); // to add all panels to formPanel
        formPanel.add(cylinderPanel, gbc);
        formPanel.add(spherePanel, gbc);
        formPanel.add(prismPanel, gbc);
        formPanel.add(pyramidPanel, gbc);

        gbc.gridy++; // to move down

        JButton submitButton = new JButton("Calculate");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        submitButton.setBackground(Color.WHITE);
        submitButton.setForeground(new Color(30, 60, 90));
        submitButton.setFocusPainted(false);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.setOpaque(true);
        submitButton.setContentAreaFilled(true);
        formPanel.add(submitButton, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        
        Runnable updateVisibility = () -> { // to show only the panel of the shape selected
            String selected = (String) shapeselected.getSelectedItem();
            conePanel.setVisible("Cone".equals(selected));
            cylinderPanel.setVisible("Cylinder".equals(selected));
            spherePanel.setVisible("Sphere".equals(selected));
            prismPanel.setVisible("Prism".equals(selected));
            pyramidPanel.setVisible("Pyramid".equals(selected));
        };

        shapeselected.addActionListener(e -> updateVisibility.run());
        updateVisibility.run();

        submitButton.addActionListener(e -> {
            String selectedShape = (String) shapeselected.getSelectedItem();

            switch (selectedShape) { // for calculation
                case "Cone": { // calculations for cone
                    try {
                        double radius = Double.parseDouble(coneRadius.getText());
                        double height = Double.parseDouble(coneHeight.getText());
                        double volume = (1.0 / 3.0) * Math.PI * radius * radius * height;
                        double surface = Math.PI * radius * (radius + Math.sqrt(radius * radius + height * height));
                        coneRadius.setText("");
                        coneHeight.setText("");
                        coneVolume.setText(" " + volume);
                        coneSurface.setText(" " + surface);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for radius and height.");
                    }
                    break;
                }
                case "Cylinder": { // calculations for cylinder
                    try {
                        double radius = Double.parseDouble(cylinderRadius.getText());
                        double height = Double.parseDouble(cylinderHeight.getText());
                        double volume = Math.PI * radius * radius * height;
                        double surface = 2 * Math.PI * radius * (radius + height); 
                        cylinderRadius.setText("");
                        cylinderHeight.setText("");
                        cylinderVolume.setText(" " + volume);
                        cylinderSurface.setText(" " + surface);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for radius and height.");
                    }
                    break;
                }
                case "Sphere": { // calculations for sphere
                    try {
                        double radius = Double.parseDouble(sphereRadius.getText());
                        double volume = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
                        double surface = 4 * Math.PI * Math.pow(radius, 2);
                        sphereRadius.setText("");
                        sphereVolume.setText(" " + volume);
                        sphereSurface.setText(" " + surface);
                        
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter a valid number for radius.");
                    }
                    break;
                }
                case "Prism": { // calculations for prism
                    try {
                        double width = Double.parseDouble(prismWidth.getText());
                        double length = Double.parseDouble(prismLength.getText());
                        double height = Double.parseDouble(prismHeight.getText());

                        double baseArea = width * length;
                        double volume = baseArea * height;
                        double surface = 2 * (width * length + length * height + width * height);

                        prismWidth.setText("");
                        prismLength.setText("");
                        prismHeight.setText("");
                        prismVolume.setText(" " + volume);
                        prismSurface.setText(" " + surface);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for width, length, and height.");
                    }
                    break;
                }
                case "Pyramid": { // calculations for pyramid
                    try {
                        double width = Double.parseDouble(pyramidWidth.getText());
                        double length = Double.parseDouble(pyramidLength.getText());
                        double height = Double.parseDouble(pyramidHeight.getText());

                        double baseArea = width * length;
                        double volume = (1.0 / 3.0) * baseArea * height;
                        double slantHeightLength = Math.sqrt((width / 2) * (width / 2) + height * height);
                        double slantHeightWidth = Math.sqrt((length / 2) * (length / 2) + height * height);
                        double surface = baseArea + (width * slantHeightWidth) + (length * slantHeightLength);

                        pyramidWidth.setText("");
                        pyramidLength.setText("");
                        pyramidHeight.setText("");
                        pyramidVolume.setText(" " + volume);
                        pyramidSurface.setText(" " + surface);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for width, length, and height.");
                    }
                    break;
                }
            }
        });


        frame.setVisible(true);
    }

    private static JLabel styledLabel(String text) { // for styledLabel style
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(Color.WHITE);
      
        return label;
    }

    
    
}