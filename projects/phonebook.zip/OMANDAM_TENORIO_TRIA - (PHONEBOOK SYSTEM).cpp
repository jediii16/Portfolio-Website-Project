#include <iostream>
#include <fstream>
using namespace std;

//Node for contact data
struct contact {
    string firstName;
    string lastName;
    string phoneNumber;
    string userEmail;
};

//Node to implement BST
struct Node{
    contact data;
    Node* left;
    Node* right;
};

//Checks if phone number contains digits only
bool isNumeric(const string& str) {
    for (char ch : str) {
        if (!isdigit(ch)) return false;
    }
    return true;
}

//Validates email format
bool isValidEmail(const string& email) {
    size_t atPos = email.find('@');
    size_t dotPos = email.find('.', atPos);

    return !email.empty() &&
           atPos != string::npos &&
           dotPos != string::npos &&
           atPos > 0 &&                          
           dotPos > atPos + 1 &&                 
           dotPos < email.length() - 1;         
}

//Add Contact
void addContact(Node *&root, string fName, string lName, string phoneNum, string uEmail){
    Node *newNode = new Node;
    newNode->data.firstName = fName;
    newNode->data.lastName = lName;
    newNode->data.phoneNumber = phoneNum;
    newNode->data.userEmail = uEmail;
    newNode->left = NULL;
    newNode->right = NULL;
    
    if(root != nullptr) {
        Node* current = root;
        while (current != nullptr) {
            if (fName < current->data.firstName || 
                (fName == current->data.firstName && lName < current->data.lastName)) {
                if (current->left == nullptr) {
                    current->left = newNode;
                    break;
                }
                current = current->left;
            }
            else if (fName > current->data.firstName || 
                     (fName == current->data.firstName && lName > current->data.lastName)) {
                if (current->right == nullptr) {
                    current->right = newNode;
                    break;
                }
                current = current->right;
            } else if (fName == current->data.firstName && lName == current->data.lastName) {
                cout << "⚠️ Contact \"" << fName << " " << lName << "\" already exists." << endl;
                delete newNode;
                return;
            }
        }
            }
            else {
                root = newNode;
            }
            cout<<endl<<"✅ Contact added successfully!"<<endl;
}

//Find minimum node (used in delete)
Node* findMin(Node* root) {
    while (root->left != NULL)
        root = root->left;
    return root;
}

//Delete Contact
Node* deleteContact(Node* root, string fName, string lName) {
    if (root == NULL) {
        cout<<"❌ Person \""<<fName<<" "<<lName<<"\" not found in the phonebook."<<endl;
        return NULL;
    }

    if (fName < root->data.firstName || (fName == root->data.firstName && lName < root->data.lastName)) {
        root->left = deleteContact(root->left, fName, lName);
    } else if (fName > root->data.firstName || (fName == root->data.firstName && lName > root->data.lastName)) {
        root->right = deleteContact(root->right, fName, lName);
    } else {
        if (root->left == NULL) {
            Node* temp = root->right;
            delete root;
            cout<<"♻ Contact deleted successfully! 🙂"<<endl<<endl;
            return temp;
        } else if (root->right == NULL) {
            Node* temp = root->left;
            delete root;
            cout<<"♻ Contact deleted successfully! 🙂"<<endl<<endl;
            return temp;
        } else {
            Node* temp = findMin(root->right);
            root->data = temp->data;
            root->right = deleteContact(root->right, temp->data.firstName, temp->data.lastName);
        }
    }

    return root;
}

//Update Contact
void updateContact(Node* root, string fName, string lName){
    if(root == NULL){
        cout<<"❌ Person \""<<fName<<" "<<lName<<"\" not found in the phonebook."<<endl;
        return;
    }
    if(root->data.firstName == fName && root->data.lastName == lName){
        cout<<endl<<"✏️ Updating contact for \""<<fName<<" "<<lName<<"\""<<endl<<endl;
        contact& con = root->data;
        string input;

        cout<<"Current Phone Number: "<<con.phoneNumber<<endl;
        cout<<"Enter new Phone Number (leave empty to keep): ";
        getline(cin, input);
        if(!input.empty()){
            if(isNumeric(input)) {
                con.phoneNumber=input;
            } else {
                cout << "❌ Invalid phone number entered. Keeping old phone number." << endl;
            }
        }

        cout<<"Current Email: "<<con.userEmail<<endl;
        cout<<"Enter new Email (leave empty to keep): ";
        getline(cin, input);
        if(!input.empty()){
            if(isValidEmail(input)) {
                con.userEmail = input;
            } else {
                cout << "❌ Invalid email entered. Keeping old email." << endl;
            }
        }

        cout<<"✅ Contact updated successfully! 🙂"<<endl<<endl;
        return;
    }

    if (fName < root->data.firstName || (fName == root->data.firstName && lName < root->data.lastName)) {
        updateContact(root->left, fName, lName);
    } else {
        updateContact(root->right, fName, lName);
    }
}


//Search contact
void searchContact(Node* root, string fName, string lName) {
    if (root == NULL) {
        cout << "Person \"" << fName <<" "<< lName << "\" not found in the phonebook."<<endl<<endl;
        return;
    }
    if (root->data.firstName == fName && root->data.lastName == lName) {
        cout <<endl<< "Person \"" << fName <<" "<< lName << "\" found in the phonebook."<<endl;
        cout<<
        root->data.firstName<<" "<<
        root->data.lastName<< " - "<<
        root->data.phoneNumber<<" - "<<
        root->data.userEmail<<endl<<endl;
        return;
    }

    if (fName < root->data.firstName || (fName == root->data.firstName && lName < root->data.lastName)) {
            searchContact(root->left, fName, lName);
    } 
    else {
        searchContact(root->right, fName, lName);
    }
}

//Display Contacts using In-order Traversal
void displayContact(Node* root){
    if (root == NULL){
        return;
    }
    displayContact(root->left);
    cout<<
    root->data.firstName<<" "<<
    root->data.lastName<< " - "<<
    root->data.phoneNumber<<" - "<<
    root->data.userEmail<<endl;
    displayContact(root->right);
}

//Saving Contacts to a .txt
void saveContacts(Node* root, ofstream &file) {
    if (root == NULL) return;
    saveContacts(root->left, file);

    cout << "Saving contact: " << root->data.firstName << " " << root->data.lastName << endl;

    file << root->data.firstName << " ";
    file << root->data.lastName << " - ";
    file << root->data.phoneNumber << " - ";
    file << root->data.userEmail << endl;

    file.flush();

    saveContacts(root->right, file);
}

//Load Contacts from .txt file
void loadContacts(Node *&root, const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "📂 No existing contact file found. Starting with an empty phonebook.\n\n";
        return;
    }

    string fName;
    string lName;
    string dash; 
    string phone;
    string email;
    while (file >> fName >> lName >> dash >> phone >> dash >> email) {
        addContact(root, fName, lName, phone, email);
    }

    file.close();
    cout << "📂 Contacts loaded successfully from " << filename << "!" << endl << endl;
}

//Deletes the whole tree to free memory
void deleteTree(Node* root) {
    if (root == nullptr) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

//MAIN
int main() {
    int y = 0;
    Node *root = NULL;
    
    //Welcome Message
    cout<<"**********************************************************"<<endl;
    cout<<"*   Welcome to Omandam, Tenorio, and Tria's Phonebook!   *"<<endl;
    cout<<"**********************************************************"<<endl<<endl;

    //Calls loadContacts function upon running the program
    loadContacts(root, "conbook.txt"); 
    do {
        contact con;
        int choice;
        //MENU
        cout<<"!==== PHONEBOOK MENU ====!"<<endl;
        cout<<
        "1.) Add Contact"<<endl<<
        "2.) Delete Contact"<<endl<<
        "3.) Update Contact"<<endl<<
        "4.) Search Contact"<<endl<<
        "5.) Display All Contacts"<<endl<<
        "6.) Save All Contacts (in a .txt File)"<<endl<<
        "7.) Exit the program"<<endl<<
        endl<< "Enter your choice: ";
        cin>>choice;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "❌ Invalid Choice. Please enter a number." << endl;
            continue;
        }
        cin.ignore();
        switch (choice){
            case 1: //Case 1: Add Contact
            cout<<endl;
            cout<<"╔══════════════════════════════╗";
            cout<<endl;
            cout<<"║       + Add New Contact      ║";
            cout<<endl;
            cout<<"╚══════════════════════════════╝" ;
            cout<<endl;
                //First Name input
                    do {
                        cout << "Enter First Name: ";
                        getline(cin, con.firstName);
                        if (con.firstName.empty()) {
                            cout<< "❌ First name cannot be empty. Please try again."<<endl;
                        }
                    } while (con.firstName.empty());
            
                //Last Name input
                    do {
                        cout << "Enter Last Name: ";
                        getline(cin, con.lastName);
                        if (con.lastName.empty()) {
                            cout<<"❌ Last name cannot be empty. Please try again."<<endl; 
                        }
                    } while (con.lastName.empty());
            
                //Phone Number input
                    do {
                        cout << "Enter Phone Number (eg., 09759330520): ";
                        getline(cin, con.phoneNumber);
                        if (con.phoneNumber.empty() || !isNumeric(con.phoneNumber)) {
                           cout<< "❌ Invalid phone number. Please enter digits only."<<endl;
                        }
                    } while (con.phoneNumber.empty() || !isNumeric(con.phoneNumber));
                
                //Email input
                    do {
                        cout << "Enter Email (eg., name@example.com): ";
                        getline(cin, con.userEmail);
                        if (!isValidEmail(con.userEmail)) {
                            cout<< "❌ Invalid email format. Please try again."<<endl;
                        }
                    } while (!isValidEmail(con.userEmail));
                    
                addContact(root, con.firstName, con.lastName, con.phoneNumber, con.userEmail); //Calls addContact function and passes the values
                cout<<"-=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=--=-"<<endl<<endl;
                break;
                
            case 2: //Case 2: Delete Contact
                //First Name input
                do {
                    cout << "Enter the first name of the contact to delete: ";
                    getline(cin, con.firstName);
                } while (con.firstName.empty());
                //Last Name input
                do {
                    cout << "Enter the last name of the contact to delete: ";
                    getline(cin, con.lastName);
                } while (con.lastName.empty());
            
                deleteContact(root, con.firstName, con.lastName); //Calls deleteContact function and passes the values
                break;
                
            case 3: //Case 3: Update Contact
                //First Name input
                do {
                    cout << "Enter the first name of the contact to update: ";
                    getline(cin, con.firstName);
                } while (con.firstName.empty());
                //Last Name input
                do {
                    cout << "Enter the last name of the contact to update: ";
                    getline(cin, con.lastName);
                } while (con.lastName.empty());
            
                updateContact(root, con.firstName, con.lastName); //Calls updateContact function and passes the values
                break;
                
            case 4: //Case 4: Search Contact
                //First Name input
                do {
                cout<<"Enter the first name you want to search for: ";
                getline(cin, con.firstName);
                } while (con.firstName.empty());
                //Last Name input
                do {
                cout<<"Enter the last name you want to search for: ";
                getline(cin, con.lastName);
                } while (con.lastName.empty());
                searchContact(root, con.firstName, con.lastName); //Calls searchContact function and passes the values
                break;
                
            case 5: //Case 5: Display All Contacts
                cout<< "╔══════════════════════════════════════╗" << endl;
                cout<< "║          📋 List of Contacts         ║" << endl;
                cout<< "╚══════════════════════════════════════╝" << endl;
    
                displayContact(root); //Calls displayContact function
                cout<<endl<<endl;
                break;
                
            case 6: { //Case 6: Save to .txt file
                //Checks if there are contacts to be saved
                if (root == NULL) { 
                    cout << "No contacts to save." << endl << endl;
                } else {
                    cout << "Contacts to be saved:" << endl;
                    displayContact(root); //Calls displayContact function
                    
                    ofstream file("conbook.txt"); //Opens the .txt file stream
                    //Displays an error message if the file failed to open
                    if (!file) {
                        cerr << "❌ Error opening file." << endl;
                        return 1;
                    } else {
                        saveContacts(root, file); //Calls the saveContacs function
                        file.flush(); //To force save
                        file.close(); //Closes the file stream
                        cout << "📁 Contacts saved successfully to conbook.txt!" << endl << endl; 
                    }
                }
                break;
            }
            case 7: //Case 7: Exit the program
                deleteTree(root); //Calls the deleteTree fucntion before exiting the program
                cout<< "You have exited the program. Thank you!" << endl; //Thank you message :D
                y = 1;
                break;
            
            default: //default: For when a user inputted random characters
                cout<<"❌ Invalid Choice. Please enter a valid number(1-7)."<<endl;
                break;
        }
    } while (y == 0);
    return 0;
}